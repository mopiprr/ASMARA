namespace ASMARA.API.Models.Ticket;

public class TicketDto
{
    
}
    
public record TicketResponseDto(
    Guid Id,
    Guid? ParentTicketId,
    Guid EmployeeId,
    string? EmployeeName,
    string TicketNumber,
    byte TicketType,
    string Subject,
    string? Description,
    Guid? AssignedToEmployeeId,
    string? AssignedTo,
    DateTime CreatedAt,
    DateTime? ClosedAt,
    DateTime? UpdatedAt,
    Guid? CurrentTaskEmployeeId,
    string CurrentStep,
    MaintenanceDetailResponseDto? MaintenanceDetail = null,
    List<ProcurementDetailResponseDto>? ProcurementDetails = null,
    List<TicketWorkflowHistoryDto>? History = null,
    bool CanApprove = false,
    bool CanRevise = false,
    bool CanReject = false,
    bool CanReceiveGoods = false,
    bool CanResubmit = false,
    bool CanAssignHandler = false,
    bool CanSendItem = false,
    bool CanReceiveItem = false,
    string? PurchaseProofFileName = null,
    string? RequesterDepartment = null
);

public record TicketWorkflowHistoryDto(
    string? Action,   
    string ActionLabel, 
    string FromStep,
    string ToStep,
    Guid EmployeeId,
    string? EmployeeName, 
    string? Note,
    DateTime CreatedAt
);

public record TicketListItemDto(
    Guid Id,
    string TicketNumber,
    string Subject,
    DateTime CreatedAt,
    string CurrentStep,
    byte TicketType,
    string CurrentStepName);

public record PendingTicketListItemDto(
    Guid Id,
    string TicketNumber,
    byte TicketType,
    string TicketTypeName,
    string Subject,
    Guid RequesterId,
    string RequesterName,
    DateTime CreatedAt,
    string CurrentStep,
    string CurrentStepName,
    string? RequesterDepartment = null);

public record MyTicketStatisticsDto(
    int TotalRequests,
    int ActiveRequests,
    int ClosedRequests,
    int RejectedRequests);