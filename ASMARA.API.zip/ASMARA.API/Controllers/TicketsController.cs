using ASMARA.API.Common.Paging;
using ASMARA.API.Features.Tickets.Queries.GetAllMyTicketsQuery;
using ASMARA.API.Features.Tickets.Queries.GetCompletedTickets;
using ASMARA.API.Features.Tickets.Queries.GetPendingTickets;
using ASMARA.API.Features.Tickets.Queries.GetTicketDetail;
using ASMARA.API.Models.Ticket;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ASMARA.API.Controllers;

[ApiController]
[Route("api/tickets")]
[Authorize]
public class TicketsController(ISender sender) : ControllerBase
{
    [HttpGet("{id:guid}")]
    public async Task<ActionResult<TicketResponseDto>> GetById(Guid id, CancellationToken ct)
        => Ok(await sender.Send(new GetTicketByIdQuery(id), ct));

    [HttpGet]
    public async Task<ActionResult<PagedResult<TicketListItemDto>>> GetMyTickets([FromQuery] GetAllMyTicketsQuery query, CancellationToken ct)
       => Ok(await sender.Send(query, ct));

    [HttpGet("pending")]
    public async Task<ActionResult<PagedResult<PendingTicketListItemDto>>> GetPendingTickets([FromQuery] GetPendingTicketsQuery query, CancellationToken ct)
       => Ok(await sender.Send(query, ct));

    [HttpGet("pending/{id:guid}")]
    public async Task<ActionResult<TicketResponseDto>> GetPendingTicketById(Guid id, CancellationToken ct)
       => Ok(await sender.Send(new GetPendingTicketByIdQuery(id), ct));

    [HttpGet("completed")]
    public async Task<ActionResult<PagedResult<CompletedTicketListItemDto>>> GetCompletedTickets([FromQuery] GetCompletedTicketsQuery query, CancellationToken ct)
       => Ok(await sender.Send(query, ct));

    [HttpGet("completed/my")]
    public async Task<ActionResult<PagedResult<CompletedTicketListItemDto>>> GetMyCompletedTickets([FromQuery] GetCompletedTicketsQuery query, CancellationToken ct)
       => Ok(await sender.Send(query with { OnlyMyTickets = true }, ct));
}