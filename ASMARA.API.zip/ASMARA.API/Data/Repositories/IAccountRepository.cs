﻿using ASMARA.API.Entities;

namespace ASMARA.API.Data.Repositories;

public interface IAccountRepository : IRepository<Account>;
